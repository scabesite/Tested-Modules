if [ "$(id -u)" -ne 2000 ]; then
    echo "[Error | @HenVx | Hendi]"
    exit 1
fi

echo ""
echo "
╭━━━┳━━━┳━━╮╭━━━┳━━━┳━━╮╭━━━┳━━━┳━╮╱╭╮
┃╭━╮┃╭━╮┣┫┣╯┃╭━╮┃╭━━┫╭╮┃┃╭━╮┃╭━╮┃┃╰╮┃┃
┃┃╱╰┫╰━━╮┃┃╱┃╰━╯┃╰━━┫╰╯╰┫┃╱┃┃╰━╯┃╭╮╰╯┃
┃┃╭━╋━━╮┃┃┃╱┃╭╮╭┫╭━━┫╭━╮┃┃╱┃┃╭╮╭┫┃╰╮┃┃
┃╰┻━┃╰━╯┣┫┣╮┃┃┃╰┫╰━━┫╰━╯┃╰━╯┃┃┃╰┫┃╱┃┃┃
╰━━━┻━━━┻━━╯╰╯╰━┻━━━┻━━━┻━━━┻╯╰━┻╯╱╰━╯"
echo " VERSION ×  4.2 FINAL "
echo " OLEH       ×  HENVX "
echo ""
echo ""
echo ""
echo " ゲーム "
echo " Proses Menghapus GSI SYSTEM ! ! "
sleep 5
echo " [■□□□□□□□□□] "
sleep 2
echo " [■■□□□□□□□□]  "
sleep 2
echo " [■■■□□□□□□□] "
sleep 2
echo " [■■■■□□□□□□]  "
sleep 2
echo " [■■■■■□□□□□] "
sleep 2
echo " [■■■■■■□□□□] "
sleep 2
echo " [■■■■■■■□□□] "
sleep 2
echo " [■■■■■■■■□□]  "
sleep 2
echo " [■■■■■■■■■□] "
sleep 0.5
echo " ゲーム"
echo " GSI SYSTEM Berhasil Terhapus ! !"
echo ""
nohup sh /sdcard/gsi/android/system > /dev/null &